Moved to https://mason-registry.dev/registry/list
