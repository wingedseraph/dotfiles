# Extras

## Reproducer

Download the [reproducer](https://raw.githubusercontent.com/nvim-focus/focus.nvim/master/extras/repro.lua) and start it with:

    nvim -u repro.lua

Once done zip the `repro.lua` and `.repro` directory and upload it.
