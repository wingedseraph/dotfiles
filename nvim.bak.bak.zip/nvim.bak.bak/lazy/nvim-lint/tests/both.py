#!/usr/bin/env python

import sys

sys.stdout.write('tests/both.py:10: foo\n')
sys.stderr.write('tests/both.py:20: bar\n')
